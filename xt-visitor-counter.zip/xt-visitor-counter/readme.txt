=== XT Visitor Counter ===
Contributors: xtrsyz
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=9GW78JRGZAP8E&lc=ID&item_name=XT%20Visitor%20Counter&item_number=426267&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donate_SM%2egif%3aNonHosted
Tags: Visitor counter, visitor traffic, traffic statistics, traffic counter, blog stats, blog traffic, traffic count
Requires at least: 3.0.1
Tested up to: 6.1.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

XT Visitor Counter is a widgets which will display the Visitor counter and traffic statistics on WordPress. Some of the features offered include Today Visitor, Today Hits, Total Hits, Total Visit, Who's Online and IP Address Visitors.

== Description ==

XT Visitor Counter is a widgets which will display the Visitor counter and traffic statistics on WordPress.Some of the features offered include Today Visitor, Today Hits, Total Hits, Total Visit, Who's Online and IP Address Visitors.

Upload and Install XT Visitor Counter Plugins, Activate and Drag the Widgets in to your WordPress Sidebar. And this plugins will useless for a thousands of websites. If you were here, download and install it, you'll like it.


== Installation ==

This section describes how to install the plugin and get it working.

1. Upload `xt-visitor-counter.zip` to the `/wp-content/plugins/` directory. You can do this using 'Upload' functionality provided in plugins section of your wordpress dashboard
2. Activate the plugin through the `Plugins` menu in WordPress
3. Go to `Appearance` >> `Widgets` and drag `XT - Visitor Counter` in to your WordPress sidebar
4. Save
5. You are done. 

== Frequently Asked Questions ==

= How to add more counter Images? =

As of now, adding another counter images, you can do to access the folder "styles/image/" on the installation of plugins


== Screenshots ==

1. Sample display
2. Widget options
3. Image counter options

== Changelog ==


Plug-in is now compatible upto wordpress version 4.5.3


== Arbitrary section ==

Refer Installation and FAQ section for all required information

== A brief Markdown Example ==

Ordered list:

1. Most simple plugin available so far
1. Do not remove developer plugins link

== Upgrade Notice ==
Upgrade your already installed plug-ins to latest version 1.0